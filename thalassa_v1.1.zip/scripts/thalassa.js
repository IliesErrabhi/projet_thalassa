

// class point
// range ([0..1],[0..1])
class Point {

    constructor (x,y) {
        this.x=x;
        this.y=y;
    }

    //assuming n is y coordinate
    // range [0..1]
    horizontalSymmetry(n) {
        const new_x = this.x;
        var   new_y = this.y;
        const delta = this.y -n;
        new_y       = n - delta;
        return new Point(new_x,new_y);
        
    }

    //assuming n is x coordinate
    // range [0..1]
    verticalSymmetry(n) {
        var  new_x  = this.x;
        const new_y = this.y;
        const delta = this.x-n;
        new_x       = n - delta;    
        return new Point(new_x,new_y);
    }

    // average beetween this point and p argument
    average(p, alpha) {
        var new_x=(this.x + p.x/2)*alpha;
        var new_y=(this.y + p.y/2)*alpha;
        return new Point(new_x,new_y);
    }

    // clone point passed in argument
    clone(p) {
        return new Point(p.x,p.y);
    }

}


//Create a composite color from R G B
class Color {
    constructor (red,green,blue) {
        this.red=red;
        this.green=green;
        this.blue=blue;
    }

    value() {
        return "rgb("+this.red+","+this.green+","+this.blue+")";
      }
}



// class Segment from 2 points
class Segment {

    constructor (p1,p2, color) {
        this.p1=p1;
        this.p2=p2;
        this.color=color;
    }


    horizontalSymmetry (n) {
        return new Segment(
                this.p1.horizontalSymmetry(n),
                this.p2.horizontalSymmetry(n),
                this.color
            );
    }

    verticalSymmetry (n) {
        return Segment(
                this.p1.verticalSymmetry(n),
                this.p2.verticalSymmetry(n),
                this.color 
            );
    }

    average(p, alpha) {
        return Segment(
            this.p1.average(p,alpha),
            this.p2.average(p,alpha),
            this.color 
        );
    }

}



class Model {
    constructor(tab) {
        this.dataModel = [];

        tab.forEach(element => {
            const x1= element[0][0];
            const y1= element[0][1];
            const x2= element[1][0];
            const y2= element[1][1];

            const p1 = new Point(x1,y1);
            const p2 = new Point(x2,y2);
            const color = new Color(100,10,200);

            this.dataModel.push(new Segment(p1,p2,color));

        });
    }
 
    paint (ctx) {
        this.dataModel.forEach(segment => {         
           ctx.strokeStyle = segment.color.value();
            ctx.beginPath();
               ctx.moveTo(segment.p1.x, segment.p1.y);
               ctx.lineTo(segment.p2.x, segment.p2.y);
             ctx.stroke(); 
          });
         
    }


}


const  model_one = [
        [[40,230],[80,270]],
        [[80,270],[300,270]],
        [[300,270],[350,230]],
        [[350,230],[40,230]],
        [[180,230],[170,120]],
        [[170,120],[220,150]],
        [[220,150],[180,180]],
        [[40,230],[40,230]],
        [[40,230],[40,230]],
        [[40,230],[40,230]],
        [[40,230],[40,230]],
        [[40,230],[40,230]]
    ];

const model_two = [
        [[150,160],[140,120]],
        [[140,120],[210,120]],
        [[210,120],[210,180]],
        [[210,180],[110,180]],
        [[110,180],[100,110]],
        [[100,110],[190,50]],
        [[190,50],[290,100]],
        [[290,100],[280,200]],
        [[280,200],[170,230]],
        [[170,230],[60,190]],
        [[60,190],[60,50]],
        [[60,50],[160,70]]
    ];


